// ── CART STORAGE ──
function getCart(){ try{return JSON.parse(localStorage.getItem('fb_cart'))||[];}catch{return[];} }
function saveCart(c){ localStorage.setItem('fb_cart',JSON.stringify(c)); }
function getCartCount(){ return getCart().reduce((s,i)=>s+i.qty,0); }

function addToCart(name,price,img,farmer,e){
  if(e) e.stopPropagation();
  let cart=getCart();
  const ex=cart.find(i=>i.name===name);
  if(ex) ex.qty++;
  else cart.push({name,price,img,farmer,qty:1});
  saveCart(cart);
  updateCartBadges();
  showToast('✅ '+name+' added to cart!');
}

function updateCartBadges(){
  const n=getCartCount();
  document.querySelectorAll('.cart-fab-count,.nav-cart-count').forEach(el=>el.textContent=n);
}

// ── TOAST ──
function showToast(msg){
  let t=document.getElementById('toast');
  if(!t){t=document.createElement('div');t.id='toast';t.className='toast';document.body.appendChild(t);}
  t.textContent=msg; t.classList.add('show');
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>t.classList.remove('show'),2700);
}

// ── MODAL ──
function showModal(icon,title,text,btnText,btnAction){
  let o=document.getElementById('modalOverlay');
  if(!o){
    o=document.createElement('div');o.id='modalOverlay';o.className='modal-overlay';
    o.innerHTML='<div class="modal-box"><button class="modal-close" onclick="closeModal()">✕</button><div id="modalBody"></div></div>';
    document.body.appendChild(o);
    o.addEventListener('click',e=>{if(e.target===o)closeModal();});
  }
  document.getElementById('modalBody').innerHTML=`
    <div class="modal-icon">${icon}</div>
    <div class="modal-title">${title}</div>
    <div class="modal-text">${text}</div>
    <button class="btn btn-green btn-lg" onclick="${btnAction||'closeModal()'}">${btnText||'Got It ✓'}</button>`;
  o.classList.add('open');
}
function closeModal(){
  const o=document.getElementById('modalOverlay');
  if(o) o.classList.remove('open');
}

// ── MOBILE MENU ──
function toggleMob(){
  document.getElementById('mobMenu').classList.toggle('open');
}
function closeMob(){
  const m=document.getElementById('mobMenu');
  if(m) m.classList.remove('open');
}

// ── ACTIVE NAV ──
function setActiveNav(){
  const path=location.pathname.split('/').pop()||'index.html';
  document.querySelectorAll('.nav-links a, .mob-menu a').forEach(a=>{
    const href=a.getAttribute('href')||'';
    a.classList.toggle('active', href===path || (path==='' && href==='index.html'));
  });
}

// ── ON LOAD ──
document.addEventListener('DOMContentLoaded',()=>{
  updateCartBadges();
  setActiveNav();
});

// ── FARMER AUTH ──
function getFarmerSession(){ try{return JSON.parse(sessionStorage.getItem('fb_farmer'))||null;}catch{return null;} }
function saveFarmerSession(f){ sessionStorage.setItem('fb_farmer',JSON.stringify(f)); }
function logoutFarmer(){ sessionStorage.removeItem('fb_farmer'); location.href='farmer-login.html'; }

const DEMO_FARMERS=[
  {id:'f1',name:'Rajan Kumar',email:'rajan@farm.com',password:'rajan123',location:'Nashik, Maharashtra',avatar:'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',crops:'Tomatoes, Onions, Grapes'},
  {id:'f2',name:'Meena Devi',email:'meena@farm.com',password:'meena123',location:'Dehradun, Uttarakhand',avatar:'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100&h=100&fit=crop&crop=face',crops:'Spinach, Coriander'},
  {id:'f3',name:'Suresh Naik',email:'suresh@farm.com',password:'suresh123',location:'Ratnagiri, Maharashtra',avatar:'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',crops:'Alphonso Mango'},
  {id:'f4',name:'Lakshmi Rao',email:'lakshmi@farm.com',password:'lakshmi123',location:'Jalgaon, Maharashtra',avatar:'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face',crops:'Bananas, Papaya'},
];
function farmerLogin(email,password){ return DEMO_FARMERS.find(f=>f.email===email&&f.password===password)||null; }

// ── FARMER PRODUCTS ──
function getFarmerProducts(){ try{return JSON.parse(localStorage.getItem('fb_farmer_products'))||[];}catch{return[];} }
function saveFarmerProducts(p){ localStorage.setItem('fb_farmer_products',JSON.stringify(p)); }
function addFarmerProduct(product){ const p=getFarmerProducts(); product.id='fp_'+Date.now(); product.addedOn=new Date().toLocaleDateString('en-IN'); p.push(product); saveFarmerProducts(p); }
function deleteFarmerProduct(id){ saveFarmerProducts(getFarmerProducts().filter(p=>p.id!==id)); }
function updateFarmerProduct(id,updated){ const p=getFarmerProducts(); const i=p.findIndex(x=>x.id===id); if(i>-1)p[i]={...p[i],...updated}; saveFarmerProducts(p); }
